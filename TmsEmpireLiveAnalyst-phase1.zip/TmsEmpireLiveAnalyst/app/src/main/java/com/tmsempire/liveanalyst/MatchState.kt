package com.tmsempire.liveanalyst

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArraySet

/** Single source of truth for the match. Manual input only: nothing here is auto-detected or invented. */
object MatchState {
    var teamA = "TEAM A"; var teamB = "TEAM B"
    var killsA = 0; var killsB = 0
    var goldDiff = 0            // positive = Team A ahead
    var turtleA = 0; var turtleB = 0
    var lordA = 0; var lordB = 0
    var scoreboardVisible = true
    var layout = 0              // 0 landscape strip, 1 portrait strip, 2 minimal
    var autoLayout = true
    var boardX = 0              // dp offset from horizontal centre
    var boardY = 16             // dp from top
    var summary = ""            // manual analyst note (AI arrives in a later phase)

    var running = false; private set
    private var baseMs = 0L
    private var startedAt = 0L
    private var prefs: SharedPreferences? = null
    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("match", Context.MODE_PRIVATE)
        prefs = p
        teamA = p.getString("teamA", teamA)!!; teamB = p.getString("teamB", teamB)!!
        killsA = p.getInt("killsA", 0); killsB = p.getInt("killsB", 0)
        goldDiff = p.getInt("gold", 0)
        turtleA = p.getInt("turtleA", 0); turtleB = p.getInt("turtleB", 0)
        lordA = p.getInt("lordA", 0); lordB = p.getInt("lordB", 0)
        scoreboardVisible = p.getBoolean("vis", true)
        layout = p.getInt("layout", 0); autoLayout = p.getBoolean("auto", true)
        boardX = p.getInt("bx", 0); boardY = p.getInt("by", 16)
        summary = p.getString("summary", "")!!
        baseMs = p.getLong("baseMs", 0L)   // restored paused, never auto-resumed
    }

    fun elapsedMs(): Long = baseMs + if (running) SystemClock.elapsedRealtime() - startedAt else 0L

    fun start() { if (!running) { startedAt = SystemClock.elapsedRealtime(); running = true; changed() } }
    fun pause() { if (running) { baseMs = elapsedMs(); running = false; changed() } }
    fun resetMatch() {
        running = false; baseMs = 0L
        killsA = 0; killsB = 0; goldDiff = 0; turtleA = 0; turtleB = 0; lordA = 0; lordB = 0
        changed()
    }

    fun mutate(block: MatchState.() -> Unit) { block(); changed() }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    private fun changed() {
        prefs?.edit()
            ?.putString("teamA", teamA)?.putString("teamB", teamB)
            ?.putInt("killsA", killsA)?.putInt("killsB", killsB)?.putInt("gold", goldDiff)
            ?.putInt("turtleA", turtleA)?.putInt("turtleB", turtleB)
            ?.putInt("lordA", lordA)?.putInt("lordB", lordB)
            ?.putBoolean("vis", scoreboardVisible)?.putInt("layout", layout)?.putBoolean("auto", autoLayout)
            ?.putInt("bx", boardX)?.putInt("by", boardY)
            ?.putString("summary", summary)?.putLong("baseMs", elapsedMs())
            ?.apply()
        listeners.forEach { it() }
    }
}
