package com.tmsempire.liveanalyst

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var etA: EditText
    private lateinit var etB: EditText
    private lateinit var etGold: EditText
    private lateinit var etSum: EditText
    private val RED = 0xFFE10600.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); setBackgroundColor(RED); minHeight = dp(52)
        setOnClickListener { f(); window.decorView.postDelayed({ refresh() }, 600) }
    }

    private fun edit(hint: String, text: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        this.hint = hint; setText(text); inputType = type
        setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        MatchState.init(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        fun add(v: android.view.View) = root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        fun pair(a: android.view.View, c: android.view.View) = add(LinearLayout(this).apply {
            addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) })
            addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        })
        fun label(t: String) = add(TextView(this).apply { text = t; setTextColor(RED); textSize = 13f; setPadding(0, dp(12), 0, 0) })

        add(TextView(this).apply { text = "TMS EMPIRE"; setTextColor(RED); textSize = 28f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        add(TextView(this).apply { text = "AI LIVE ANALYST · Phase 1 overlay"; setTextColor(Color.WHITE) })
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(0, dp(8), 0, dp(8)) }
        add(status)

        label("SETUP")
        add(btn("1 · Grant overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        add(btn("2 · Allow notifications (Android 13+)") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        pair(btn("START OVERLAY") { startSvc(OverlayService.ACTION_START) },
            btn("STOP OVERLAY") { stopService(Intent(this, OverlayService::class.java)) })

        label("TIKTOK CAPTURE TEST (red box + counter)")
        add(btn("TOGGLE CAPTURE TEST BOX") { startSvc(OverlayService.ACTION_POC) })

        label("MATCH CONFIG")
        etA = edit("Team A", MatchState.teamA); etB = edit("Team B", MatchState.teamB)
        etGold = edit("Gold diff (+ = Team A ahead)", MatchState.goldDiff.toString(),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED)
        etSum = edit("Analyst note (manual; AI comes later)", MatchState.summary)
        add(etA); add(etB); add(etGold); add(etSum)
        add(btn("APPLY CONFIG") {
            MatchState.mutate {
                teamA = etA.text.toString().trim().ifEmpty { "TEAM A" }.uppercase()
                teamB = etB.text.toString().trim().ifEmpty { "TEAM B" }.uppercase()
                goldDiff = etGold.text.toString().toIntOrNull() ?: goldDiff
                summary = etSum.text.toString().trim()
            }
        })
        pair(btn("START / PAUSE TIMER") { if (MatchState.running) MatchState.pause() else MatchState.start() },
            btn("RESET MATCH") { MatchState.resetMatch() })

        label("OVERLAY")
        pair(btn("SHOW / HIDE BOARD") { MatchState.mutate { scoreboardVisible = !scoreboardVisible } },
            btn("CYCLE LAYOUT") { MatchState.mutate { autoLayout = false; layout = (layout + 1) % 3 } })
        add(btn("AUTO LAYOUT BY ORIENTATION") { MatchState.mutate { autoLayout = true } })
        pair(btn("◀ X") { MatchState.mutate { boardX -= 20 } }, btn("X ▶") { MatchState.mutate { boardX += 20 } })
        pair(btn("▲ Y") { MatchState.mutate { boardY = maxOf(0, boardY - 20) } }, btn("Y ▼") { MatchState.mutate { boardY += 20 } })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(root) })
    }

    private fun startSvc(action: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_LONG).show(); return
        }
        startForegroundService(Intent(this, OverlayService::class.java).setAction(action))
    }

    private fun refresh() {
        status.text = "Overlay permission: " + (if (Settings.canDrawOverlays(this)) "GRANTED" else "MISSING") +
            "\nOverlay service: " + (if (OverlayService.running) "RUNNING" else "STOPPED") +
            "\nCapture test box: " + (if (OverlayService.pocOn) "ON" else "OFF") +
            "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")" +
            "\nBackend / AI: not built yet (local-only Phase 1)" +
            "\nTikTok capture: UNTESTED until you run TESTING.md"
    }

    override fun onResume() { super.onResume(); refresh() }
}
