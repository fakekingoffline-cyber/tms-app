package com.tmsempire.liveanalyst

import android.content.Context
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import java.util.Locale
import kotlin.math.abs

class ScoreboardView(ctx: Context) : View(ctx) {
    var layoutMode = 0
    var moveMode = false

    private val d = ctx.resources.displayMetrics.density
    private val red = 0xFFE10600.toInt()
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6000000.toInt() }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = red }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d
    }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }

    companion object {
        fun scale(mode: Int) = if (mode == 1) 0.78f else 1f
        fun widthUnits(mode: Int) = if (mode == 2) 210f else 420f
        fun heightUnits(mode: Int, hasSummary: Boolean) =
            if (mode == 2) 44f else 64f + if (hasSummary) 20f else 0f
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    override fun onDraw(c: Canvas) {
        val s = MatchState
        val u = scale(layoutMode) * d
        val w = width.toFloat(); val h = height.toFloat()
        val mini = layoutMode == 2
        val mainH = if (mini) h else 46f * u

        c.drawRoundRect(0f, 0f, w, h, 10f * u, 10f * u, bg)
        c.drawRoundRect(0f, 0f, 10f * u, h, 5f * u, 5f * u, accent)

        tp.textAlign = Paint.Align.CENTER
        tp.color = red; tp.textSize = 8f * u; tp.letterSpacing = 0.15f
        c.drawText("TMS EMPIRE", w / 2, mainH * 0.24f, tp)
        tp.letterSpacing = 0f
        tp.color = Color.WHITE; tp.textSize = 15f * u
        c.drawText(fmt(s.elapsedMs()), w / 2, mainH * 0.72f, tp)

        tp.textSize = 26f * u
        val ax = if (mini) w * 0.2f else w * 0.36f
        val bx = if (mini) w * 0.8f else w * 0.64f
        c.drawText(s.killsA.toString(), ax, mainH * 0.76f, tp)
        c.drawText(s.killsB.toString(), bx, mainH * 0.76f, tp)

        if (!mini) {
            val maxW = 110f * u
            tp.textSize = 13f * u
            tp.textAlign = Paint.Align.LEFT
            c.drawText(TextUtils.ellipsize(s.teamA, tp, maxW, TextUtils.TruncateAt.END).toString(),
                16f * u, mainH * 0.66f, tp)
            tp.textAlign = Paint.Align.RIGHT
            c.drawText(TextUtils.ellipsize(s.teamB, tp, maxW, TextUtils.TruncateAt.END).toString(),
                w - 10f * u, mainH * 0.66f, tp)

            c.drawRect(14f * u, mainH, w - 8f * u, mainH + u, accent)
            tp.textSize = 10f * u
            val g = s.goldDiff
            val goldText = when {
                g > 0 -> "GOLD  ${s.teamA.take(8)} +" + String.format(Locale.US, "%.1fK", g / 1000.0)
                g < 0 -> "GOLD  ${s.teamB.take(8)} +" + String.format(Locale.US, "%.1fK", abs(g) / 1000.0)
                else -> "GOLD  EVEN"
            }
            tp.textAlign = Paint.Align.LEFT
            c.drawText(goldText, 16f * u, mainH + 14f * u, tp)
            tp.textAlign = Paint.Align.RIGHT
            c.drawText("TURTLE ${s.turtleA}-${s.turtleB}   LORD ${s.lordA}-${s.lordB}",
                w - 10f * u, mainH + 14f * u, tp)

            if (s.summary.isNotBlank()) {
                tp.textAlign = Paint.Align.LEFT; tp.color = 0xFFCCCCCC.toInt()
                val t = TextUtils.ellipsize("ANALYST: " + s.summary, tp, w - 26f * u, TextUtils.TruncateAt.END)
                c.drawText(t.toString(), 16f * u, mainH + 32f * u, tp)
            }
        }
        if (moveMode) c.drawRoundRect(1f, 1f, w - 1f, h - 1f, 10f * u, 10f * u, outline)
    }
}
