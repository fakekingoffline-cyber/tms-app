package com.tmsempire.liveanalyst

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs
import kotlin.math.min

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.tmsempire.START"
        const val ACTION_POC = "com.tmsempire.POC"
        @Volatile var running = false
        @Volatile var pocOn = false
        private const val CH = "tms_overlay"
        private const val OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        private const val NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        private const val NT = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        private const val NTM = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        private const val RED = 0xFFE10600.toInt()
    }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var d = 1f
    private var board: ScoreboardView? = null
    private var boardLp: WindowManager.LayoutParams? = null
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var poc: PocView? = null
    private var moveBtn: TextView? = null
    private var movingBoard = false

    private val listener: () -> Unit = { h.post { refreshBoard() } }
    private val tick = object : Runnable {
        override fun run() { board?.invalidate(); poc?.step(); h.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (!running) setup()
        if (intent?.action == ACTION_POC) togglePoc()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Overlay", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("TMS EMPIRE overlay active")
            .setContentText("Tap to open controls")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun setup() {
        running = true
        MatchState.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density

        board = ScoreboardView(this).also { v ->
            val lp = WindowManager.LayoutParams(10, 10, OVERLAY, NF or NT, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            boardLp = lp
            wm.addView(v, lp)
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
            v.setOnTouchListener { _, e ->   // only receives touches while "Move board" is ON
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; true }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                        wm.updateViewLayout(v, lp); true
                    }
                    MotionEvent.ACTION_UP -> {
                        MatchState.mutate { boardX = (lp.x / d).toInt(); boardY = (lp.y / d).toInt() }; true
                    }
                    else -> false
                }
            }
        }
        buildBubble()
        MatchState.addListener(listener)
        refreshBoard()
        h.postDelayed(tick, 1000)
    }

    private fun resolvedLayout(): Int =
        if (MatchState.autoLayout)
            (if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) 1 else 0)
        else MatchState.layout

    private fun refreshBoard() {
        val v = board ?: return; val lp = boardLp ?: return
        val s = MatchState
        val m = resolvedLayout()
        v.layoutMode = m
        val sc = ScoreboardView.scale(m)
        val maxW = resources.displayMetrics.widthPixels - (8 * d).toInt()
        lp.width = min((ScoreboardView.widthUnits(m) * sc * d).toInt(), maxW)
        lp.height = (ScoreboardView.heightUnits(m, s.summary.isNotBlank()) * sc * d).toInt()
        lp.x = (s.boardX * d).toInt(); lp.y = (s.boardY * d).toInt()
        v.visibility = if (s.scoreboardVisible) View.VISIBLE else View.GONE
        v.invalidate()
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
        bubbleLp?.let { b ->
            b.x = b.x.coerceIn(0, maxOf(0, resources.displayMetrics.widthPixels - (44 * d).toInt()))
            b.y = b.y.coerceIn(0, maxOf(0, resources.displayMetrics.heightPixels - (44 * d).toInt()))
            bubble?.let { try { wm.updateViewLayout(it, b) } catch (_: Exception) {} }
        }
    }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); refreshBoard() }

    private fun buildBubble() {
        val size = (44 * d).toInt()
        val t = TextView(this).apply {
            text = "T"; setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(RED); setStroke((2 * d).toInt(), Color.WHITE) }
        }
        // Window is only 44dp: everything outside it keeps passing touches to the game.
        val lp = WindowManager.LayoutParams(size, size, OVERLAY, NF or NTM, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (8 * d).toInt(); lp.y = (140 * d).toInt()
        bubble = t; bubbleLp = lp
        wm.addView(t, lp)
        var rx = 0f; var ry = 0f; var sx = 0; var sy = 0; var moved = false
        t.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; sx = lp.x; sy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - rx; val dy = e.rawY - ry
                    if (abs(dx) > 8 * d || abs(dy) > 8 * d) moved = true
                    if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
    }

    private fun pbtn(label: String, onClick: (TextView) -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setBackgroundColor(0xFFB00500.toInt()); minHeight = (44 * d).toInt()
        setOnClickListener { onClick(this) }
    }

    private fun row(a: View, b: View?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        val m = (3 * d).toInt()
        fun lp() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(m, m, m, m) }
        addView(a, lp()); if (b != null) addView(b, lp())
    }

    private fun togglePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {}; panel = null; return }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt()) }
        val s = MatchState
        col.addView(row(pbtn("A +1 KILL") { s.mutate { killsA++ } }, pbtn("B +1 KILL") { s.mutate { killsB++ } }))
        col.addView(row(pbtn("A −1") { s.mutate { killsA = maxOf(0, killsA - 1) } }, pbtn("B −1") { s.mutate { killsB = maxOf(0, killsB - 1) } }))
        col.addView(row(pbtn("GOLD A +500") { s.mutate { goldDiff += 500 } }, pbtn("GOLD B +500") { s.mutate { goldDiff -= 500 } }))
        col.addView(row(pbtn("TURTLE A") { s.mutate { turtleA++ } }, pbtn("TURTLE B") { s.mutate { turtleB++ } }))
        col.addView(row(pbtn("LORD A") { s.mutate { lordA++ } }, pbtn("LORD B") { s.mutate { lordB++ } }))
        col.addView(row(pbtn("START / PAUSE") { if (s.running) s.pause() else s.start() },
            pbtn("BOARD ON/OFF") { s.mutate { scoreboardVisible = !scoreboardVisible } }))
        moveBtn = pbtn("MOVE BOARD: OFF") { setMove(!movingBoard) }
        col.addView(row(pbtn("LAYOUT") { s.mutate { autoLayout = false; layout = (layout + 1) % 3 } }, moveBtn))
        col.addView(row(pbtn("CLOSE PANEL") { togglePanel() }, null))
        val sv = ScrollView(this).apply {
            addView(col)
            background = GradientDrawable().apply { setColor(0xF2101010.toInt()); setStroke((2 * d).toInt(), RED); cornerRadius = 12 * d }
        }
        val pw = (250 * d).toInt(); val ph = (280 * d).toInt()
        val b = bubbleLp!!
        val sw = resources.displayMetrics.widthPixels; val shh = resources.displayMetrics.heightPixels
        val lp = WindowManager.LayoutParams(pw, ph, OVERLAY, NF or NTM, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (b.x + (52 * d).toInt() + pw <= sw) b.x + (52 * d).toInt() else maxOf(0, b.x - pw - (4 * d).toInt())
        lp.y = min(b.y, maxOf(0, shh - ph))
        panel = sv
        wm.addView(sv, lp)
    }

    private fun setMove(on: Boolean) {
        movingBoard = on
        board?.moveMode = on
        boardLp?.flags = if (on) NF else (NF or NT)
        board?.let { try { wm.updateViewLayout(it, boardLp) } catch (_: Exception) {}; it.invalidate() }
        moveBtn?.text = if (on) "MOVE BOARD: ON" else "MOVE BOARD: OFF"
    }

    private fun togglePoc() {
        val p = poc
        if (p != null) { try { wm.removeView(p) } catch (_: Exception) {}; poc = null; pocOn = false; return }
        val v = PocView(this)
        val lp = WindowManager.LayoutParams((300 * d).toInt(), (120 * d).toInt(), OVERLAY, NF or NT, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = (16 * d).toInt(); lp.y = (300 * d).toInt()
        poc = v; pocOn = true
        wm.addView(v, lp)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        MatchState.removeListener(listener)
        listOf<View?>(board, bubble, panel, poc).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        board = null; bubble = null; panel = null; poc = null
        running = false; pocOn = false
        super.onDestroy()
    }
}
