package com.tmsempire.liveanalyst

import android.content.Context
import android.graphics.*
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Capture-test graphic: red rectangle + brand text + counter + wall-clock (to measure stream delay). */
class PocView(ctx: Context) : View(ctx) {
    private var counter = 0
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint().apply { color = 0xFFE10600.toInt() }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun step() { counter++; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, fill)
        tp.textSize = 26f * d; c.drawText("TMS EMPIRE", w / 2, h * 0.38f, tp)
        tp.textSize = 20f * d; c.drawText("COUNT $counter", w / 2, h * 0.66f, tp)
        tp.textSize = 14f * d; c.drawText(clock.format(Date()), w / 2, h * 0.9f, tp)
    }
}
