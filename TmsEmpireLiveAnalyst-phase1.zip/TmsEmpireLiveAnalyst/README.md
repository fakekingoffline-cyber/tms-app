# TMS EMPIRE AI LIVE ANALYST – Phase 1 (floating overlay)

Native Kotlin, no third-party dependencies, minSdk 26, targetSdk 34.

## Build
1. Install Android Studio (Koala+). File → Open → this folder. Let Gradle sync (needs internet once).
2. Build → Build APK(s) → app/build/outputs/apk/debug/app-debug.apk
3. Install: `adb install -r app-debug.apk`, or copy to the phone and open it (allow unknown sources).

## Use
Open app → 1 Grant overlay permission → 2 Allow notifications → START OVERLAY.
Red "T" bubble = controls (tap to expand, drag to move). "MOVE BOARD" lets you drag the scoreboard.
Then follow TESTING.md.

## Structure
- MatchState.kt – manual match data, saved to SharedPreferences (timer restores paused)
- OverlayService.kt – foreground service (specialUse), scoreboard window, bubble, panel, test box
- ScoreboardView.kt – Canvas-drawn scoreboard, 3 layouts (landscape / portrait / minimal)
- PocView.kt – red rectangle + TMS EMPIRE + counter + clock
- MainActivity.kt – permissions, start/stop, match config

## Known limitations
- NOT compiled or run in the environment that generated it: expect to fix small build errors.
- TikTok capture of overlays is UNVERIFIED. Treat as unknown until TESTING.md is done.
- All data is manual. No OCR, no backend, no Claude API yet (later phases).
- "Connection status" shows permission/service state only; there is no network layer yet.
- ColorOS may kill background services: set battery to "Don't optimise" for the app.
- Android 12+ restricts touch-through on overlays; the app uses NOT_TOUCHABLE windows for that reason.
- No launcher icon / logo asset yet (text logo only).
