# TikTok capture test (highest priority)

Goal: prove what a VIEWER receives, not what the phone shows.

## Setup
- Phone A: this app + TikTok. Phone/PC B (or a second account): watches the live as a real viewer.
- Note Android version + build number (shown in app status). Test Wi-Fi and mobile data.

## Procedure
1. Install APK, grant overlay + notification permissions, tap START OVERLAY.
2. Tap TOGGLE CAPTURE TEST BOX. Confirm red box + counter visible on phone.
3. Open TikTok → LIVE → Mobile game / screen-share mode. Accept the Android capture
   prompt. On Android 14+ choose "Entire screen" (NOT single app) – an app-only
   capture can exclude other apps' windows. Record what the prompt offered.
4. Start live (use a private/low-risk setup if TikTok allows). Switch to MLBB.
   Confirm on phone A the red box is still on screen above the game.
5. On viewer device B, check: red box visible? text readable? counter increasing?
   Compare box clock vs real time = stream delay (usually seconds).
6. Repeat with: scoreboard on, portrait + landscape, bubble panel open, MLBB in
   foreground for 10+ minutes (does Oppo ColorOS kill the service? battery temp?).
7. Gameplay touches: tap through the area around bubble/board in MLBB – nothing
   should be swallowed (board is NOT_TOUCHABLE; bubble window is only 44dp).

## Record per run
Device / Android / ColorOS version | TikTok version | capture mode chosen |
box visible to viewer Y/N | scoreboard visible Y/N | delay s | service survived Y/N

## If the overlay is NOT in the viewer's stream
Do not bypass restrictions (no FLAG_SECURE tricks, no hooking TikTok). Options:
- Check TikTok mode: some modes capture only the game/app surface, not overlays.
- Supported architecture B: stream via an RTMP-capable app that composites your own
  graphics inside its own capture (requires a stream key/access TikTok currently
  grants you – verify TikTok's current eligibility rules).
- Architecture C: second device (PC/TikTok LIVE Studio + browser source) – breaks the one-phone goal.
Report results before Phase 2.
